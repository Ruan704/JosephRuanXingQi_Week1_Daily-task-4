var arr = [10, 12, 90, 93, 707];
const odds = arr.filter(number => {
    return number % 2 !== 0;
  });
  
  console.log("these number are odd: ",odds); 

  const even = arr.filter(number => {
    return number % 2 === 0;
  });
  
  console.log("these number are even: ",even); 