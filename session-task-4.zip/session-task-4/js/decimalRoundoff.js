var arr = [9.8, 9.7, 4.5, 3.4];

var sumValue = 0;

for (var i = 0; i < arr.length; i++) {
  sumValue += arr[i];
}

console.log(Math.round(sumValue));