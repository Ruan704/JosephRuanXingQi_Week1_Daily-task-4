const arrVal = [20, 19, 45, 100];
const findVal = arrVal.find((ele) => {
    return ele > 20;
});

console.log(findVal);