addVal = () => {
    console.log(10 + 20);
}

addVal();

divisionVal = () => {
    console.log(20 / 10);
}

divisionVal();

subtractionVal = () => {
    console.log(20 - 10);
}

subtractionVal();