var salary = [{salary: 56000, },{ salary: 90000}]

  let sumSal = 0;
  
  for (let j = 0; j < salary.length; j++) {
  
    sumSal += salary[j].salary;
  
  }
  
  console.log(sumSal);