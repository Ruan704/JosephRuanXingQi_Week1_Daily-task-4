const employee = 'Joseph';
for(let e of employee) {
    console.log(e);
}
