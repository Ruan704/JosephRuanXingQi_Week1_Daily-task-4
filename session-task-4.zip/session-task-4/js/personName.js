let arrayOfPerson = [{

    firstName: 'joe',
    
    age: 24
    
    }, {
    
    firstName: 'alina',
    
    age: 12
    
    },
    
    {
    
    firstName: 'alex',
    
    age: 20
    
    }]

 var array = arrayOfPerson.filter(arrayOfPerson => arrayOfPerson.age >= 18)
    console.log(array)