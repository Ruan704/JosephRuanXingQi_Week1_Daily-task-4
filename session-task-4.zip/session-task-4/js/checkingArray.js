let arrayOfObject = [{
    firstName: 'alina',
    id: 1,
    age: 14
    }, {
    firstName: 'harry',
    id: 2,
    age: 15
    }, {
    firstName: 'alex',
    id: 3,
    age: 16
    }]
    let found = arrayOfObject.some(obj => {
        if (obj.firstName == 'alina' && obj.firstName == 'harry' && obj.firstName == 'alex') {
        return true;
          }
        else{
             return false;
        }
        });
        
        console.log(found);