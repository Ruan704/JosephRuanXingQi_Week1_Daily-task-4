var arr = [90, 89, 56, 45];

var sumValue = 0;

for (var i = 0; i < arr.length; i++) {
    sumValue  += arr[i];
}

console.log(sumValue)