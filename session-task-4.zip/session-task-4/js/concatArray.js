var color = ['red', 'pink', 'orange', 'red'];
console.log(color.toString(),color.join(''));//'20'
