const friends = [
  {
    firstName: "alina",
    id: 1,
    age: 14,
  },
  {
    firstName: "harry",
    id: 2,
    age: 15,
  },
  {
    firstName: "alex",
    id: 3,
    age: 16,
  },
];

const result = friends.filter(function (ele) {
  return ele.id == 2;
});
console.log(result);

