
class Electronics {
  constructor(name, version, companyName) {
    this.name = name;
    this.version = version;
    this.companyName = companyName;
  }
}

class Laptop extends Electronics {
  constructor(name, version, companyName, price) {
    super(name, version, companyName);
    this.price = price;
  }
  configuration(size) {
    if (size > 1000) {
      console.log(`This is big.`);
    } else {
      console.log(`This is small.`);
    }
  }
}

class Ipad extends Electronics {
  constructor(name, version, companyName, price) {
    super(name, version, companyName);
    this.price = price;
  }
  configuration(size) {
    if (size > 1000) {
      console.log(`This is big.`);
    } else {
      console.log(`This is small.`);
    }
  }
}

class Mobile extends Electronics {
  constructor(name, version, companyName, price) {
    super(name, version, companyName);
    this.price = price;
  }
  configuration(size) {
    if (size > 500) {
      console.log(`This is big.`);
    } else {
      console.log(`This is small.`);
    }
  }
}

class Tablet extends Electronics {
  constructor(name, version, companyName, price) {
    super(name, version, companyName);
    this.price = price;
  }
  configuration(size) {
    if (size > 1000) {
      console.log(`This is big.`);
    } else {
      console.log(`This is small.`);
    }
  }
}

