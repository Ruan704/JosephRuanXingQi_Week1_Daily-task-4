
let text = "i am learning js";
if(result = text.includes("js")){
    console.log("It exists")
}else{
    console.log("It does not exists")
}