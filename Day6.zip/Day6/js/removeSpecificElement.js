var array=["12","56","89"]
var removeElement = prompt("remove a specific element from an array: ");
var newArray = array.filter((value)=>value!= removeElement);
console.log(newArray);