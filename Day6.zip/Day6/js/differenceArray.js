var arr = [12, 56, 789];
var arr2 = [12, 56, 789];

var minus = arr.map((arr, i) => arr - arr2[i]);

console.log(minus);