var chars = [10, 50, 20, 67, 10, 20];

let uniqueChars = [...new Set(chars)];

console.log(uniqueChars);
