evenNumber = parseInt(prompt("Please add only even number inside thanks."))
var number = [2,4,6,8];//array of strings
if (evenNumber % 2 == 0) {
    console.log(evenNumber)
    console.log("num is even number")
    number.push(evenNumber);// add element in the end of an array
    console.log(number);
}else{
    console.log("Its not an even number");
}
