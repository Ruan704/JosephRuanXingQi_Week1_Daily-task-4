const num1 =  Math.PI ;
const ex1 = num1.toFixed(3);
console.log(ex1); // 👉️ 13.00

