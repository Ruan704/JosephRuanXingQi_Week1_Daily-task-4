class Car {
    //pre-defined method: that is used initialize value
    constructor(name, brand, color, manufacture) {
        this.name = name;
        this.brand = brand;
        this.color = color;
        this.manufacture = manufacture
    }

    display() {

    }

    city() {
        console.log(`Hello, my name is ${this.name} , ${this.brand} and I am manufacture in ${this.manufacture}`);
      }

      specialFeature() {
        console.log(`Also based on your info I am ${this.color} in color`);
      }
}

const car = new Car(" i4","BMW","Estoril Blue","Germany");//creating a object
console.log(car);