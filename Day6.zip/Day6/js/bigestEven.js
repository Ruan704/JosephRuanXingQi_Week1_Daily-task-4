var arr = [10, 12, 90, 93, 707];
var largest = arr[0];

for (var i = 0; i < arr.length; i++ && i%2 ==0) {
    if (largest < arr[i] && arr[i] % 2 ==0) {
        largest = arr[i];
    }
}
console.log(largest);
