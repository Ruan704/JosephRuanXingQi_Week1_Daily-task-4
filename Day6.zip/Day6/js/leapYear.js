year = parseInt(prompt("Which year do u want to enter?"))
if(year%4 == 0){
    console.log("Its a leap year")
}else{
    console.log("Its isn't a leap year")
}