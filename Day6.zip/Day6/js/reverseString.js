var text = "i am learning js";

var text1 = text.split("");

console.log(text1)

var text2 = text1.reverse();
console.log(text2)

var text3 = text2.join("");
console.log(text3)
