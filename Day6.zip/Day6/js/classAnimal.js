class Animal {
    //pre-defined method: that is used initialize value
    constructor(gender , name, disease) {
        this.gender = gender;
        this.name = name;
        this.disease = disease;
    }

    display() {

    }

    walk() {
        console.log(`Hello, my name is ${this.name} , I am ${this.gender} and I am sick in ${this.disease}`);
      }

      eat() {
        console.log(`Hello, my name is ${this.name} , I am ${this.gender} and I am sick in ${this.disease}`);
      }
      climb(){
        console.log(`Hello, my name is ${this.name} , I am ${this.gender} and I am sick in ${this.disease}`);
      }
}

const animal = new Animal("male","bat","covid");//creating a object
console.log(animal);