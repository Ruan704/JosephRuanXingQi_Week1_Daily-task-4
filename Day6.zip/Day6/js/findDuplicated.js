var array = [5 , 8 , 9 , 1, 4 , 1]

var string = array.toString();
console.log(string)


const toFindDuplicates = array => array.filter((item, index) => array.indexOf(item) !== index)
const duplicateElementa = toFindDuplicates(array);
console.log(duplicateElementa);

console.log(string.search(duplicateElementa));
