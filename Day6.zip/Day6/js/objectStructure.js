const firstName = 'Joseph';
const lastName = 'Ruan';
const age = 22;

const user = { firstName, lastName, age };

console.log(user);