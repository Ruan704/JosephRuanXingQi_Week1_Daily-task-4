var array = [10, 78, 90] 
function max_even(arra) {

    arra.sort((x, y) => y - x);
  
    for (var i = 0; i < arra.length; i++) {
  
      if (arra[i] % 2 == 0) return arra[i];
  
    }
  
  }
  
  
  
  console.log(max_even(array));