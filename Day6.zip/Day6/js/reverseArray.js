var arr = [10, 78, 0];
 
for (var i = arr.length - 1; i >= 0; i--) {
    console.log(arr[i]);
}