class Book {
    //pre-defined method: that is used initialize value
    constructor(noofpages, typeofpages, author) {
        this.noofpages = noofpages;
        this.typeofpages = typeofpages;
        this.author = author;
    }

    display() {

    }

      type_of_book(){
        console.log(`Also based on your info I am written by ${this.author} and I have ${this.noofpages}`);
      }

}

const book = new Book(50,20,"Stephen Edwin King");//creating a object
console.log(book);